/*
 * File:   sensor.c
 * Author: Hp
 *
 * Created on 7 October, 2025, 5:48 PM
 */


#include <xc.h>
#include "ssd.h"
#include "adc.h"
#include "can.h"

//extern unsigned char ssd[4];
extern int value;
extern unsigned char indicator;
void rpm()
{
    value = read_adc(CHANNEL4) * 5.866; //(6000/1024)the potentiometer has only value upto 1023 , so we are convert that value in reference to 6000
    
//    ssd[3] = digits[value % 10];
//    ssd[2] = digits[(value/10)%10];
//    ssd[1] = digits[(value/100)%10];
//    ssd[0] = digits[value/1000];
//    
//    display(ssd);
}
void send_data()
{
    value = read_adc(CHANNEL4) * 5.866; //(6000/1024)the potentiometer has only value upto 1023 , so we are convert that value in reference to 6000
    
    char send[3];
    send[0] = value & 0xFF; //extract lsb bits
    send[1] = (value >> 8) & 0xFF;//extract msb bits
    can_transmit(RPM_MSG_ID,&send,2);
    for(int i =1000; i>0; i--);
    
    send[0] = indicator;
    can_transmit(IND_MSG_ID,&send,1);
    for(int i =1000; i>0; i--);
}
