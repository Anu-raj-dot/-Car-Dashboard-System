/*
 * File:   ssd.c
 * Author: Hp
 *
 * Created on 7 October, 2025, 5:50 PM
 */


#include <xc.h>

void init_ssd()
{
    TRISD = 0x00;//set portd as o/p as data line
    TRISA = TRISA & 0xF0;//set last 4 pin as o/p as control line
    PORTA = PORTA & 0xF0;//set control as 0 
}

void display(unsigned char *ssd)
{
    for(int i=0; i<4; i++)
    {
        PORTD = ssd[i]; // add data to data line based on ssd led config[d0-d7]
        PORTA = (PORTA & 0xF0) | (1<<i);// activate control lines one by one
        
        for(unsigned int delay = 500; delay--; );// delay given to avoid overlap data in ssd
    }
}

