/* 
 * File:   ssd.h
 * Author: Hp
 *
 * Created on 7 October, 2025, 5:46 PM
 */

#ifndef SSD_H
#define	SSD_H

unsigned char digits [] = {0xE7, 0x21, 0xCB, 0x6B, 0x2D, 0x6E, 0xEE, 0x23, 0xEF, 0x6F};

void init_ssd();
void display(unsigned char *ssd);

#endif	/* SSD_H */

