/* 
 * File:   dkps.h
 * Author: Hp
 *
 * Created on 7 October, 2025, 5:45 PM
 */

#ifndef DKPS_H
#define	DKPS_H

#define EDGE 0
#define LEVEL 1

#define left_ind     0
#define right_ind    1
#define hazard_ind   2
#define stop_ind     3

unsigned char switch_read(unsigned char option);


#endif	/* DKPS_H */

