/*
 * File:   main.c
 * Author: Hp
 *
 * Created on 7 October, 2025, 5:44 PM
 */


#include <xc.h>
#include "dkps.h"
#include "can.h"
#include "ssd.h"
#include "adc.h"
#include "sensor.h"
#include "clcd.h"

//unsigned char ssd[4];
int value = 0;
unsigned char indicator = 3;
//char *str[4] = {"<-","->","<-->"," "};
//
//void itoa(int value,char* str)
//{
//    int i = 0;
//    
//    if(value == 0)
//    {
//        str[i++] = 48;
//        str[i] = '\0';
//        return;
//    }
//    
//    while(value != 0)
//    {
//        str[i++] = (value % 10) + 48;
//        value /= 10;
//    }
//    str[i] = '\0';
//    
//    int index = i-1;
//    i=0;
//    
//    while(i < index)
//    {
//        int temp = str[i];
//        str[i] = str[index];
//        str[index] = temp;
//        i++;
//        index--;
//    }
//    return;
//}

void init_config()
{
//    TRISB = 0x00; //set portb as o/p for led
//    PORTB = 0x00;
  //  TRISE0 = 0;
    
    TRISC = TRISC | 0X0F;//set portc as i/p for switch
//    init_clcd();//initalize clcd
    init_adc();//initalize adc
//    init_ssd();//initalize ssd
    init_can();//initalize can
    
}
void main(void) {
    
    init_config();
    
    unsigned char key, button;
    unsigned int delay = 0,rpm1 =0;
    //unsigned char left_ind = 0, right_ind = 0, hazard_ind = 0;
    uint16_t msg_id;
    uint8_t data[8], length;
    
    
    while(1)
    {
//          ssd[3] = digits[rpm1 % 10];
//          ssd[2] = digits[(rpm1/10)%10];
//          ssd[1] = digits[(rpm1/100)%10];
//          ssd[0] = digits[rpm1/1000];
//          display(ssd);
          
        rpm();
        send_data();
        
//        can_receive(&msg_id, &rpm1, &length); 
//            
//        if(msg_id == RPM_MSG_ID)
//        {
//            //rpm1 = ((unsigned int)data[1] << 8) | (unsigned int)data[0];
//            char buff[5] = {0};
//            itoa(rpm1,buff);
//    
//            if(rpm1 < 1000 && rpm1 >100)
//            {
//             buff[3] = ' ';
//            }
//            else if(value >10 && value < 100)
//            {
//             buff[2] = ' ';
//             buff[3] = ' ';
//            }
//            else if(value >-1 && value < 10)
//            {
//             buff[1] = ' ';
//             buff[2] = ' ';
//             buff[3] = ' ';
//            }
//            clcd_print("RPM:", LINE2(0));
//            clcd_print(buff, LINE2(4));
//        }
          
        if((key = switch_read(EDGE)) != 0x0F);
        {
            PORTB = 0x00;
         //   RE0 = 0;
        }
        
        if(key == 0x0E )
        {
//            left_ind = !left_ind;
//            right_ind = 0;
//            hazard_ind = 0;
              indicator = left_ind;
        }
        else if(key == 0x0D)
        {
//            PORTB = 0x00;
//         
//            left_ind = 0;
//            right_ind = 0;
//            hazard_ind = 0;
            indicator = stop_ind;
        }
        else if(key == 0x0B)
        {
//            right_ind = !right_ind;
//            left_ind = 0;
//            hazard_ind = 0;
            indicator = right_ind;
        }
        else if(key == 0x07)
        {
//            left_ind = 0;
//            right_ind = 0;
//            hazard_ind = !hazard_ind;
            indicator = hazard_ind;
        }

        //rpm1 = (int)indicator;
      //  can_transmit(INDICATOR_MSG_ID, &indicator, 1);
//        can_receive(&msg_id, &data[0], &length);
//        rpm1 = (int)data[0];
//        
//        if(msg_id == INDICATOR_MSG_ID)
//        {                  
//            button = data[0];
////            char str[5];
////            itoa((int)button,str);
////            clcd_print("ind:", LINE1(8));
////            clcd_print(str, LINE1(12));
////            clcd_print("IND:", LINE2(8));
////            clcd_print(&str[0], LINE2(12));
//        }
//        
//        if(button == stop_ind)
//        {
//            PORTB = 0x00;
//        }
//        
//        if(delay++ == 30 && button == left_ind)
//        {
//          //  RE0 = !RE0;
//            PORTB ^= 0x03;
//        }      
//        else if(delay == 30 && button == right_ind)
//        {
//          //  RE0 = !RE0;
//            PORTB ^= 0xC0;
//        }
//        else if(delay == 30 && button == hazard_ind)
//        {
//           // RE0 = !RE0;
//            PORTB ^= 0xC3;
//        }
//        else if(delay > 30)
//            delay = 0;
    }
    return;
}
