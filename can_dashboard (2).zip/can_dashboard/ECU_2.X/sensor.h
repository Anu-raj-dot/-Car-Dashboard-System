/* 
 * File:   sensor.h
 * Author: Hp
 *
 * Created on 7 October, 2025, 5:46 PM
 */

#ifndef SENSOR_H
#define	SENSOR_H

void rpm();
void send_data();

#endif	/* SENSOR_H */

