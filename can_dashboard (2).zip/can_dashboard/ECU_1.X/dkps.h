/* 
 * File:   dkps.h
 * Author: Hp
 *
 * Created on 7 October, 2025, 5:45 PM
 */

#ifndef DKPS_H
#define	DKPS_H

#define EDGE 0
#define LEVEL 1

unsigned char switch_read(unsigned char option);


#endif	/* DKPS_H */

