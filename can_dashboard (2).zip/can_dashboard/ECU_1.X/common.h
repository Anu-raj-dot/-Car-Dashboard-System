/* 
 * File:   common.h
 * Author: Hp
 *
 * Created on 9 October, 2025, 11:46 AM
 */

#ifndef COMMON_H
#define	COMMON_H

void itoa(int value,char* str);

#endif	/* COMMON_H */

