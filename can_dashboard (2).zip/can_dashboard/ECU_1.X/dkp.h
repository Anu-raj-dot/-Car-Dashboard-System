/* 
 * File:   dkp.h
 * Author: Hp
 *
 * Created on 16 October, 2025, 4:25 PM
 */

#ifndef DKP_H
#define	DKP_H

void dkp();

#endif	/* DKP_H */

