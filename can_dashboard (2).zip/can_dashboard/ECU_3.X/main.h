/* 
 * File:   main.h
 * Author: Hp
 *
 * Created on 22 October, 2025, 7:06 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#define left_ind     0
#define right_ind    1
#define hazard_ind   2
#define stop_ind     3

#endif	/* MAIN_H */

